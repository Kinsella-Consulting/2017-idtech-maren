The Original Textures for 'CandyCraft' belong to Nathan Long who's Minecraft Forum alias is 'NightHaunt'. You can download the original textures and pack here: http://www.minecraftforum.net/topic/91347-16x16125-candycraft/

'CandyCraft: The Sweet Redemption', is a Minecraft texture pack under the ownership of Sam Stephens under the alias 'OmniGlitcher'. 
The texture pack can be downloaded from either the website 'Mediafire' via the website 'Minecraft Forum' (http://www.minecraftforum.net/topic/1727138-16x1615-candycraft-the-sweet-redemption/) or via the alternate host 'minecrafttexturepacks.com' which I have given permission to host, but do not take responsibility for any actions they take.

This pack will be surrended to the original owner upon request of the orignal author 'NightHaunt'in the form of a Private Message on the website 'www.minecraftforum.net' to the account 'OmniGlitcher'