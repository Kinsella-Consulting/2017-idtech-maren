WHAT TIME IS IT?

ADVENTURE TIME CRAFT!

-------------------
INSTALLATION
-------------------

1. Start up Minecraft.
2. At the main menu, hit the "Options" button.
3. Near the bottom, hit the "Resource Packs" button. A new screen should appear and allow you to select a resource pack.
4. Hit the "Open resource pack folder" button and a new window will pop up outside the game. Drop the AdventureTimeCraft-9.0.zip file into this window.
5. Close the window and return to Minecraft. It should appear in your texture pack list.
6. Simply select AdventureTimeCraft-9.0.zip and click the "Done" button on the bottom

-------------------
VERSIONS
-------------------

9.0
-Updated for 1.7.2 includes
  -Redid the logs to better reflect their wood plank counterparts
  -Finally got to use those abandoned textures from when I supported BetterGrass mod!
  -New items and menus

8.0
-Updated for 1.6.2 includes
  -Horse textures!
  -And others I guess GOSH I'M TIRED

7.0
-Updated for 1.5.1 includes
  -New clock and compass animations!
  -New blocks relating to 1.5.1

6.1
-Updated for 1.4.7 includes
  -FIREWORKS AAAAAH OH GOD YESSSS!
  -Miscellaneous GUI tweeks and new items!
  -Changed Marceline to Magic Man on the suggestion of WierdCrafter4143 on the forums. Good idea, mate!

6.0
-Updated for 1.4.5 includes
  -New blocks!
  -NEW 32 WIDE BREAK ANIMATIONS FINALLY!
  -ALSO ATTEMPTED TO REWORK WHEAT I GUESS!
  -Witches are Marceline!
  -Withers are Marceline's Dad!

5.0
-Updated for 1.3.1 includes
  -Boxes of circuit boards for currency!
  -New GUI's!
  -Books I guess!

4.0
-Crystal realm is now Night-O-Sphere
-Updated Spider textures

3.1
-Updated for 1.2.3 that include:
  -Spawn Eggs!
  -New swords from the talented Arkisys!
  -Various blocks!
  -New BMO mask view!

3.0
-A whole bunch of updates, including new terrain items (lily pad, End portal, etc), moon phases, brand new cavespider texture, villager textures, half hearted attempt at coloring dragon, book.png, items, new GUI windows and some new paintings to put up in your house
-BRAND NEW COBBLESTONE TEXTURE that replaces the terrible one that we all hated earlier

2.5
-A whole bunch of updates, including updating various blocks to reflect the light hearted post-apocalyptic setting of the show (iron deposits depicted as old rebar)
-Brand new smooth and cobble/moss stones, brick, clay, blue dye deposits and blocks, sandstone, coal deposit, iron (deposits and block), gold(deposits and block), diamond(deposits and block), redstone deposit, piston and mushrooms, note/record player sides.
-Boring old pumpkin is now BMO! You'll find BMO lying in an open field but stick a candle in him, he'll come back to life!
-Cloth redesigned to be more like colored, generic building blocks to build structures with.
-Lightened up the terrain greatly to better reflect the cartoony nature of the show.
-!BRAND NEW! Much improved biome support! I'm very excited to get this out!

2.4
-Updated for 1.8, new things!
-Made cows cows, sheep sheep and pigs pigs! Items they drop have been changed to reflect this too.
-Made Smooth Stone more smoother and a little more organic so that they don't overpower the brick and cobble textures

2.3
-Added piston texture pack, invalidating it seems Wild Grass support.
-Removed cow, pig and sheep textures simply because I wasn't satisfied with them and some people didn't like them either.

2.2
-Updated for 1.6.x (Maps, achievement window, tall grass etc)
-Made the cookie into the donut instead. Bread is now pizza.
-Fixed GUI name plates
-Added custom water, lava and portal animations

2.1.2
-Added WildGrass Support
-Fixed the redstone circuit graphics some more!

2.1.1
-Fixed the redstone circuit graphics

2.1
-Added Powered Rail, Detector Rail, Biome Side Grass, Pine and Birch saplings
-Adjusted clouds to show a clear day when you start out
-Added sleeves to the armors

2.0
-Switched up to 32 x 32
-Complete redux of all tiles for extra detail 32 x 32 affords
-Converted the Nether into the Crystal Dimension. Zombie Pigmen are now Crystal Men.
-Ghost Man is now Monster Jelly Cube
-Penguin is now chicken
-Good tree trunks is now one of the little pigs
-Weird pony is now a carebear
-Changed gravel textures to be more gravelly


1.0
-Initial Release

-------------------
THINGS TO DO
-------------------

+Animated fire. If you're familiar with fire, it doesn't have a well defined shape.

-------------------
QUESTIONS & SUGGESTIONS?
-------------------

PM me, leonel, on www.minecraftforum.net